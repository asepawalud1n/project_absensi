<footer class="py-4 border-t border-gray-700">
    <div class="text-center">
        <p class="text-xs text-gray-400">
            &copy; <?php echo e(date('Y')); ?> Asep Awaludin. All rights reserved.
        </p>
       
    </div>
</footer>
<?php /**PATH C:\laragon\www\absensi-sekolah\resources\views/filament/footer.blade.php ENDPATH**/ ?>