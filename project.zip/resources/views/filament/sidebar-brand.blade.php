<div class="flex items-center gap-2 px-2 py-3">
    <img src="{{ asset('images/binusa.png') }}" alt="Logo" class="w-10 h-10 object-contain">
    <p class="text-xs font-bold text-gray-900 dark:text-white whitespace-nowrap">SMK BINTANG NUSANTARA</p>
</div>
