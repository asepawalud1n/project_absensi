<footer class="py-4 border-t border-gray-700">
    <div class="text-center">
        <p class="text-xs text-gray-400">
            &copy; {{ date('Y') }} Asep Awaludin. All rights reserved.
        </p>
       
    </div>
</footer>
