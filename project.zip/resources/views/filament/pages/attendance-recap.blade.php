<x-filament-panels::page>
    {{ $this->table }}
</x-filament-panels::page>