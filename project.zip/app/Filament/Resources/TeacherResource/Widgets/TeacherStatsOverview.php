<?php

namespace App\Filament\Resources\TeacherResource\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class TeacherStatsOverview extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
