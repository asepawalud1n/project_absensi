<?php

return [
    'email' => 'Kolom :attribute harus berupa alamat email yang valid.',
    'required' => 'Kolom :attribute wajib diisi.',
    'attributes' => [
        'email' => 'email',
        'password' => 'kata sandi',
    ],
];