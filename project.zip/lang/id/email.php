<?php

return [
    'greeting' => 'Halo!',
    'salutation' => 'Salam,',
    'regards' => 'Salam,',
    'action' => 'Klik tombol di bawah untuk :action',
    'verify_email' => 'Verifikasi Email',
];