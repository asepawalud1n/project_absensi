<?php

return [
    'failed' => 'Email atau Kata sandi yang anda masukan salah.',
    'password' => 'Kata sandi yang diberikan salah.',
    'throttle' => 'Terlalu banyak percobaan login. Silakan coba lagi dalam :seconds detik.',
];