<?php

return [
    'verify_email' => [
        'greeting' => 'Halo!',
        'line1' => 'Silakan klik tombol di bawah untuk memverifikasi alamat email Anda.',
        'action' => 'Verifikasi Alamat Email',
        'line2' => 'Jika Anda tidak membuat akun, abaikan email ini.',
    ],
];