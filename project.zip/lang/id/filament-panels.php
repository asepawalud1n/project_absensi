<?php

return [
    'pages' => [
        'email_verification' => [
            'notification' => [
                'heading' => 'Verifikasi alamat email Anda',
                'actions' => [
                    'resend' => [
                        'label' => 'Kirim ulang',
                    ],
                ],
            ],
        ],
    ],
];